# ros-moveit-arm
Code and configuration files for 3D printed arm controlled with ROS and MoveIt
